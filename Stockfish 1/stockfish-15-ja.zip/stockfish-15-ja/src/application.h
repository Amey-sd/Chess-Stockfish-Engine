/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2009 Marco Costalba

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#if !defined(APPLICATION_H_INCLUDED)
#define APPLICATION_H_INCLUDED


/// Singleton class used to housekeep memory and global resources
/// so to be sure we always leave in a clean state.

class Application {

  Application();
  Application(const Application&);
 ~Application();

public:
  static void initialize();
  static void exit_with_failure();
};

#endif // !defined(APPLICATION_H_INCLUDED)
