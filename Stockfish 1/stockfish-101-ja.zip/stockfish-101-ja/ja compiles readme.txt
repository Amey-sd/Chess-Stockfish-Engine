
The msvc p.g.o compiles should be tried first as they are the fastest.

If you have problems running engine properly (hogging processor) on 
2 core (and above) systems, try the other compiles. Msvc pgo using pthreads
should be faster than gcc 4 compile.

Jim Ablett [05-11-08]